const calc = require('../controller/calculate');
const router = require('express').Router();

router.post('/', calc.numberOperation);

router.get('/results',(req, res)=>{

    console.log(req.query);
    res.send('The result is: '+req.query.results);
});

module.exports = router;